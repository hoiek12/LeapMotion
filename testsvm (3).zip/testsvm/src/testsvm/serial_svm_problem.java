package testsvm;

import java.io.Serializable;
import libsvm.svm_problem;

public class serial_svm_problem extends svm_problem implements Serializable{

}
